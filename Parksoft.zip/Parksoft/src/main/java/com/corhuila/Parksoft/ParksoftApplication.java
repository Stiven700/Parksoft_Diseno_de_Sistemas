package com.corhuila.Parksoft;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParksoftApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParksoftApplication.class, args);
	}

}
